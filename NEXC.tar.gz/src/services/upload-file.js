import axiosInstance from "../axiosConfig";
class UploadFileService {
  async uploadFileToS3() {
    console.log("upload file");
  }
}

export default new UploadFileService();
