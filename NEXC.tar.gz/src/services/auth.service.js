import axiosInstance from "../axiosConfig";

class AuthService {
  async loginWithEmail(email, password) {
    try {
      const response = await axiosInstance.post("/auth/login", {
        loginType: "email",
        email,
        password,
      });
      if (response.data.accessToken) {
        this.setUserData(response.data);
      }
      return response.data;
    } catch (error) {
      console.error("Login error:", error);
      throw error;
    }
  }

  async logout() {
    try {
      localStorage.removeItem("user");
      localStorage.removeItem("accessToken");
      localStorage.removeItem("refreshToken");
    } catch (error) {
      console.error("Logout error:", error);
    }
  }

  async register(name, email, password, registrationType) {
    try {
      const response = await axiosInstance.post("/user/registration", {
        name,
        email,
        password,
        registrationType,
      });
      if (response.data.accessToken) {
        this.setUserData(response.data);
      }
      return response.data;
    } catch (error) {
      console.error("Registration error:", error);
      throw error;
    }
  }

  getCurrentUser() {
    try {
      return JSON.parse(localStorage.getItem("user"));
    } catch (error) {
      console.error("Error getting current user:", error);
      return null;
    }
  }

  setUserData(data) {
    localStorage.setItem("user", JSON.stringify(data.user));
    localStorage.setItem("accessToken", JSON.stringify(data.accessToken));
    localStorage.setItem("refreshToken", JSON.stringify(data.refreshToken));
  }
}

const authService = new AuthService();
export default authService;