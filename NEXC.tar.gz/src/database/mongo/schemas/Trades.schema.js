const mongoose = require("mongoose");

const tradeSchema = mongoose.Schema({
  title: { type: String, required: [true, "Trade Name is required"] },
  description: { type: String },
  isAvailable: { type: Boolean, default: true },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now },
});

// Add a pre-save middleware to update the 'updatedAt' field
tradeSchema.pre('save', function(next) {
  this.updatedAt = Date.now();
  next();
});

const Trade = mongoose.model("trades", tradeSchema);
module.exports = Trade;