import PropTypes from "prop-types";
import React, { useEffect } from "react";

// material-ui
import { makeStyles } from '@mui/styles';
import { CardContent, Grid, Tab, Tabs, Typography } from "@mui/material";

import ConstructionIcon from '@mui/icons-material/Construction';
import HealthAndSafetyIcon from '@mui/icons-material/HealthAndSafety';
import PrecisionManufacturingIcon from '@mui/icons-material/PrecisionManufacturing';
import FoundationIcon from '@mui/icons-material/Foundation';
import CoursesCard from "./cards-components/CoursesCard";
import NothingHere from "../../../components/NothingHere";

// style constant
const useStyles = makeStyles((theme) => ({
  profileTab: {
    "& .MuiTabs-flexContainer": {
      borderBottom: "none",
    },
    "& button": {
      color:
        theme.palette.mode === "dark"
          ? theme.palette.grey[600]
          : theme.palette.grey[600],
      minHeight: "auto",
      minWidth: "100%",
      padding: "12px 16px",
    },
    "& button.Mui-selected": {
      color: theme.palette.primary.main,
      background:
        theme.palette.mode === "dark"
          ? theme.palette.dark.main
          : theme.palette.grey[50],
    },
    "& button > span": {
      display: "flex",
      flexDirection: "row",
      alignItems: "flex-start",
      textAlign: "left",
      justifyContent: "flex-start",
    },
    "& button > span > svg": {
      marginBottom: "0px !important",
      marginRight: "10px",
      marginTop: "10px",
      height: "20px",
      width: "20px",
    },
    "& button > span > div > span": {
      display: "block",
    },
    "& button > span > span + svg": {
      margin: "0px 0px 0px auto !important",
      width: "14px",
      height: "14px",
    },
    "& > div > span": {
      display: "none",
    },
  },
  cardPanels: {
    borderLeft: "1px solid",
    borderLeftColor: theme.palette.mode === "dark" ? "#333d5e" : "#eeeeee",
    height: "100%",
  },
}));

// tabs
function TabPanel(props) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && <div>{children}</div>}
    </div>
  );
}

TabPanel.propTypes = {
  children: PropTypes.node,
  index: PropTypes.any.isRequired,
  value: PropTypes.any.isRequired,
};

function a11yProps(index) {
  return {
    id: `simple-tab-${index}`,
    "aria-controls": `simple-tabpanel-${index}`,
  };
}

const tabsOption = [
  {
    label: "CITB",
    icon: <ConstructionIcon />,
  },
  {
    label: "Health and Safety",
    icon: <HealthAndSafetyIcon />,
  },
  {
    label: "Plant Operations",
    icon: <PrecisionManufacturingIcon />,
  },
  {
    label: "Scaffolding",
    icon: <FoundationIcon />,
  },
];

export default function ComponentCourses(props) {
  const classes = useStyles();
  const [value, setValue] = React.useState(0);
  const [category, setCategory] = React.useState("citb");

  useEffect(() => {
    let search = window.location.search;
    let params = new URLSearchParams(search);
    let queryCategory = params.get("category");

    if (
      [
        "citb",
        "health-and-safety",
        "plant-operations",
        "scaffolding",
      ].includes(queryCategory)
    ) {
      setCategory(queryCategory);
      switch (queryCategory) {
        case "citb":
          setValue(0);
          break;

        case "health-and-safety":
          setValue(1);
          break;

        case "plant-operations":
          setValue(2);
          break;

        case "scaffolding":
          setValue(3);
          break;

        default:
          setValue(0);
          break;
      }
    }
  }, [props]);

  const handleChange = (event, newValue) => {
    switch (newValue) {
      case 0:
        setCategory("citb");
        break;

      case 1:
        setCategory("health-and-safety");
        break;

      case 2:
        setCategory("plant-operations");
        break;

      case 3:
        setCategory("scaffolding");
        break;

      default:
        setCategory("citb");
        break;
    }
    setValue(newValue);
  };
  return (
    <Grid container spacing={3} sx={{ my: 10 }}>
      <Grid item xs={12} sm={props.tradeId ? 1 : 3.5}>
        <Typography variant="h5" paragraph>
          {props.title}
        </Typography>
        <Tabs
          value={value}
          onChange={handleChange}
          orientation="vertical"
          className={classes.profileTab}
          variant="scrollable"
          sx={{
            "& button": {
              borderRadius: "5px",
            },
          }}
        >
          {!props.tradeId &&
            tabsOption.map((tab, index) => (
              <Tab
                key={index}
                label={
                  <Grid container direction="row">
                    {tab.icon}
                    <Typography ml={2} variant="subtitle1" color="inherit">
                      {tab.label}
                    </Typography>
                  </Grid>
                }
                {...a11yProps(index)}
              />
            ))}
        </Tabs>
      </Grid>
      <Grid item xs={12} sm={props.tradeId ? 11 : 8.5}>
        <CardContent className={classes.cardPanels}>
          <TabPanel value={value} index={value}>
            <Grid container spacing={3}>
              {props.courses?.length ? (
                props.tradeId ? (
                  props.courses?.map((item) => (
                    <CoursesCard key={item._id} {...item} />
                  ))
                ) : (
                  props.courses
                    ?.filter((item) => item.category.toLowerCase() === category.toLowerCase())
                    ?.map((item) => <CoursesCard key={item._id} {...item} />)
                )
              ) : (
                <Grid item xs={12} lg={12}>
                  <NothingHere />
                </Grid>
              )}
            </Grid>
          </TabPanel>
        </CardContent>
      </Grid>
    </Grid>
  );
}
