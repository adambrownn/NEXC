import React from 'react';
import { motion } from "framer-motion";
// material
import { styled } from "@mui/material/styles";
import {
  Box,
  Container,
  Typography,
  Stack,
  Button,
} from "@mui/material";

import { Icon } from "@iconify/react";
import phoneCallFill from "@iconify/icons-eva/phone-call-fill";
import CSLIntro from "../../../assets/logos/csl-intro.gif";
import { Link as RouterLink } from "react-router-dom";
import { HashLink as HLink } from "react-router-hash-link";
import SendIcon from "@mui/icons-material/Send";
import { CATEGORY_PATH } from "src/routes/paths";

const RootStyle = styled(motion.div)(({ theme }) => ({
  position: "relative",
  backgroundColor: "#000",
  [theme.breakpoints.up("md")]: {
    top: 0,
    left: 0,
    width: "100%",
    height: "100vh",
    display: "flex",
    position: "fixed",
    alignItems: "center",
  },
}));

const ContentStyle = styled((props) => <Stack spacing={5} {...props} />)(
  ({ theme }) => ({
    zIndex: 10,
    maxWidth: 520,
    margin: "auto",
    textAlign: "center",
    position: "relative",
    paddingTop: theme.spacing(15),
    paddingBottom: theme.spacing(15),
    [theme.breakpoints.up("lg")]: {
      margin: "unset",
      textAlign: "left",
    },
  })
);

const HeroOverlayStyle = styled(motion.img)({
  zIndex: 9,
  width: "100%",
  height: "100%",
  objectFit: "cover",
  position: "absolute",
});

const QualCardStyle = styled('div')(({ theme }) => ({
  zIndex: 9,
  top: 100,
  width: "100%",
  position: "absolute",
  filter: `drop-shadow(40px 80px 80px rgba(0, 0, 0, 0.48))`,
  [theme.breakpoints.up("lg")]: {
    right: "8%",
    width: "auto",
    height: "48vh",
  },
  "@media (max-width: 1200px)": {
    display: "none",
  },
}));

const ActionButton = styled(Button)(({ theme }) => ({
  whiteSpace: "nowrap",
  borderRadius: 50,
  width: "5rem",
  height: "2.5rem",
  textDecoration: "none",
}));

export default function LandingHero() {
  return (
    <>
      <RootStyle initial="initial">
        <HeroOverlayStyle alt="Hero overlay" src="/static/overlay.svg" />

        <QualCardStyle>
          <img
            src={CSLIntro}
            style={{
              width: 620,
              height: 620,
              borderRadius: 15,
            }}
            alt="CSL Intro"
          />
        </QualCardStyle>

        <Container maxWidth="lg">
          <ContentStyle>
            <motion.div>
              <Typography variant="h1" sx={{ color: "common.white" }}>
                Book your <br />
                CSCS Card <br /> 
                <Typography
                  component="span"
                  variant="h1"
                  sx={{ color: "primary.main" }}
                >
                  &nbsp;today!
                </Typography>
              </Typography>
            </motion.div>

            <motion.div style={{ marginTop: ".5%", marginBottom: "5%" }}>
              <Button
                size="large"
                variant="contained"
                target="_blank"
                href="tel:+91(0)99717 14172"
                startIcon={<Icon icon={phoneCallFill} />}
                sx={{
                  margin: 3,
                  "@media (min-width: 1200px)": {
                    display: "none",
                  },
                }}
              >
                +91 (0)99717 14172
              </Button>
              <Button
                size="large"
                variant="outlined"
                component={RouterLink}
                to={CATEGORY_PATH.root}
                startIcon={<Typography>Select your Trade</Typography>}
                endIcon={<SendIcon />}
                aria-label="View all Trades"
              />
            </motion.div>

            <Stack
              direction="row"
              spacing={1.5}
              justifyContent={{ xs: "center", md: "flex-start" }}
            >
              <motion.div>
                <HLink to="/trades#csl-cards">
                  <ActionButton
                    size="small"
                    variant="outlined"
                    sx={{
                      border: "0px solid",
                      color: "black",
                      bgcolor: "#FCA700",
                      "&:hover": { bgcolor: "grey", color: "#FCA700" },
                    }}
                  >
                    Cards
                  </ActionButton>
                </HLink>
              </motion.div>
              <motion.div>
                <HLink to="/trades#csl-tests">
                  <ActionButton
                    size="small"
                    variant="outlined"
                    sx={{
                      border: "1.6px solid",
                      "&:hover": { bgcolor: "#FCA700", color: "black" },
                    }}
                  >
                    Tests
                  </ActionButton>
                </HLink>
              </motion.div>
              <motion.div>
                <HLink to="/qualifications">
                  <ActionButton
                    size="small"
                    variant="outlined"
                    sx={{
                      border: "0px solid",
                      color: "black",
                      bgcolor: "#FCA700",
                      "&:hover": { bgcolor: "grey", color: "#FCA700" },
                    }}
                  >
                    NVQ's
                  </ActionButton>
                </HLink>
              </motion.div>
              <motion.div>
                <HLink to="/trades#csl-courses">
                  <ActionButton
                    size="small"
                    variant="outlined"
                    sx={{
                      border: "1.6px solid",
                      "&:hover": { bgcolor: "#FCA700", color: "black" },
                    }}
                  >
                    Courses
                  </ActionButton>
                </HLink>
              </motion.div>
            </Stack>
          </ContentStyle>
        </Container>
      </RootStyle>
      <Box sx={{ height: { md: "100vh" } }} />
    </>
  );
}