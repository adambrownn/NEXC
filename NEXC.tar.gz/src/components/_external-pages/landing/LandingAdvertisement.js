import React from 'react';
import { styled } from "@mui/material/styles";
import { Box, Container } from "@mui/material";
import { ContactForm } from "../contact";

const ContentStyle = styled("div")(({ theme }) => ({
  maxWidth: 500,
  margin: "auto 10%",
  marginBlock: 55,
  overflow: "hidden",
  paddingBottom: theme.spacing(10),
  borderRadius: theme.shape.borderRadiusMd,
  [theme.breakpoints.up("md")]: {
    display: "flex",
    maxWidth: "100%",
    paddingBottom: 0,
    alignItems: "center",
  },
}));

export default function LandingAdvertisement() {
  return (
    <Container maxWidth="lg">
      <ContentStyle>
        <Box
          component="img"
          alt="rocket"
          src="/static/home/contact.svg"
          sx={{ maxWidth: 460, width: 1 }}
          loading="lazy"
        />
        <Box>
          <ContactForm />
        </Box>
      </ContentStyle>
    </Container>
  );
}