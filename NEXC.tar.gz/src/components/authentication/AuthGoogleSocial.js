import { Stack, Button, Divider, Typography } from "@mui/material";
import { Icon } from "@iconify/react";
import googleFill from "@iconify/icons-eva/google-fill";
import axiosInstance from "../../axiosConfig";
import { GoogleLogin } from '@react-oauth/google';

export default function AuthGoogleSocials() {
  const handleGoogleLogin = async (credentialResponse) => {
    if (credentialResponse && credentialResponse.credential) {
      let loginType = "google";
      let socialIdentityToken = credentialResponse.credential;

      try {
        await axiosInstance.post("/auth/login", {
          loginType,
          socialIdentityToken,
        });
        // Handle successful login (e.g., redirect to dashboard)
      } catch (error) {
        console.error("Google login error:", error);
        // Handle login error
      }
    }
  };

  return (
    <>
      <Stack direction="row" spacing={2}>
        <GoogleLogin
          onSuccess={handleGoogleLogin}
          onError={() => {
            console.log('Login Failed');
          }}
          render={({ onClick }) => (
            <Button
              fullWidth
              size="large"
              color="inherit"
              variant="outlined"
              onClick={onClick}
              startIcon={<Icon icon={googleFill} color="#DF3E30" height={24} />}
            >
              Continue with Google
            </Button>
          )}
        />
      </Stack>

      <Divider sx={{ my: 3 }}>
        <Typography variant="body2" sx={{ color: "text.secondary" }}>
          OR
        </Typography>
      </Divider>
    </>
  );
}