// ----------------------------------------------------------------------

const account = {
  displayName: "Kartik Tyagi",
  email: "kartik@demo.com",
  photoURL: "/static/mock-images/avatars/avatar_default.jpg",
};

export default account;
