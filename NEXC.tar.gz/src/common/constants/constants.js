module.exports = {
  dayKMSearch: 20, // KM
  nightKMSearch: 10, // KM
  earthDistanceInKM: 6378.1,
};
