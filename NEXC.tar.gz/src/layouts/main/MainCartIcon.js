import React, { useEffect, useState } from "react";

export default function MainCartIcon(props) {
  return <div></div>;
}
