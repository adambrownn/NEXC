import axios from "axios";
import AuthHeader from "./services/auth-header";
import authService from "./services/auth.service";

const baseURL = process.env.REACT_APP_API_BASE_URL ||
  (process.env.NODE_ENV === 'production'
    ? "https://api.nexc.co.uk/api/v1"  // Update this for production
    : "http://localhost:8080/api/v1"); // Update this for local development

const axiosInstance = axios.create({ baseURL });

let isAlertShown = false;

(async () => {
  const headerAccessToken = await AuthHeader.getAuthHeaderToken();
  axiosInstance.defaults.headers.common["authorization"] =
    headerAccessToken.authorizationToken;
  axiosInstance.defaults.headers.post["Content-Type"] = "application/json";

  axiosInstance.interceptors.response.use(
    (response) => {
      if (
        ["JWT expired.", "Auth token missing", "Invalid Token."].includes(
          response.data.err
        )
      ) {
        authService.logout();
        window.location.replace("/auth/login");
      }
      return response;
    },
    (error) => {
      if (error.message === "Network Error") {
        console.error("Network Error occurred:", error);
        
        // Show an alert only if one isn't already shown
        if (!isAlertShown) {
          isAlertShown = true;
          alert("A network error occurred. Some features may not work correctly. Please check your connection and contact support if the issue persists.");
        }
        
        // Return a resolved promise with a dummy response
        return Promise.resolve({
          status: 503,
          data: { message: "Service temporarily unavailable due to network issues." }
        });
      }
      return Promise.reject(error);
    }
  );
})();

export default axiosInstance;

// import axios from "axios";
// import AuthHeader from "./services/auth-header";
// import authService from "./services/auth.service";

// const axiosInstance = axios.create({
//   // baseURL: "http://localhost:8080/v1",
//   baseURL: "https://nexc.co.uk/v1",
// });

// (async () => {
//   const headerAccessToken = await AuthHeader.getAuthHeaderToken();
//   axiosInstance.defaults.headers.common["authorization"] =
//     headerAccessToken.authorizationToken;
//   axiosInstance.defaults.headers.post["Content-Type"] = "application/json";

//   axiosInstance.interceptors.request.use(
//     (request) => {
//       // console.log("axios request");
//       // console.log(request);
//       // Edit request config
//       return request;
//     },
//     (error) => {
//       // console.log(error);
//       return Promise.reject(error);
//     }
//   );

//   axiosInstance.interceptors.response.use(
//     (response) => {
//       // console.log("axios response");
//       // console.log(response);
//       if (
//         ["JWT expired.", "Auth token missing", "Invalid Token."].includes(
//           response.data.err
//         )
//       ) {
//         authService.logout();
//         window.location.replace("/aut/login");
//       }
//       // Edit response config
//       return response;
//     },
//     (error) => {
//       // console.log(error);
//       if (error.message === "Network Error") {
//         window.location.reload();
//       }
//       return Promise.reject(error);
//     }
//   );
// })();

// export default axiosInstance;
