/*
 * File: /views/index.js
 * Project: CSL
 * File Created: Saturday, 10th June 2020 3:09:32 pm
 * Author: Kartik Tyagi (kartik9756@gmail.com)

 * Copyright 2019 - 2020 Adorway
 */
