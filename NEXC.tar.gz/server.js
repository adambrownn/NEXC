const express = require("express");
const cookieParser = require("cookie-parser");
const fileUpload = require("express-fileupload");
const cors = require("cors");
const path = require("path");

require("dotenv").config({ path: "./env/.env" });

const app = express();
const PORT = process.env.PORT || 8080;

// // CORS configuration
// const corsOptions = {
//   origin: process.env.ENV === "production" 
//     ? "https://nexc.co.uk" 
//    : ["http://localhost:3000", "http://127.0.0.1:3000", "http://localhost:8080"],
//   methods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
//   allowedHeaders: ["Origin", "X-Requested-With", "Content-Type", "Accept", "Authorization"],
//   credentials: true,
//   optionsSuccessStatus: 200
// };

// // Apply CORS middleware
// app.use(cors(corsOptions));
const corsOptions = {
  origin: function (origin, callback) {
    const allowedOrigins = ['http://localhost:3000', 'http://127.0.0.1:3000', 'http://localhost:8080'];
    if (!origin || allowedOrigins.indexOf(origin) !== -1) {
      callback(null, true);
    } else {
      callback(new Error('Not allowed by CORS'));
    }
  },
  methods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
  allowedHeaders: ["Origin", "X-Requested-With", "Content-Type", "Accept", "Authorization"],
  credentials: true,
  optionsSuccessStatus: 200
};

app.get('/test-cors', (req, res) => {
  res.json({ message: 'CORS is working' });
});

app.use(cors(corsOptions));

// Preflight requests
app.options('*', cors(corsOptions));

//middleware
app.use(express.json());
app.use(cookieParser());
app.use(fileUpload());

// mongodb connection
require("./src/database/connection");

// Serve static files from the React build directory
app.use(express.static(path.join(__dirname, 'build')));

// public routes
try {
  const routes = require("./src/routes/routes");
  app.use("/api/v1", routes);
} catch (error) {
  console.error("Error importing routes:", error);
}

// Handle React routing, return all requests to React app
app.get('*', function(req, res) {
  res.sendFile(path.join(__dirname, 'build', 'index.html'));
})

// if in production
if (process.env.ENV === "production") {
  // Add production-specific configurations here
}

// Catch-all route for handling 404 errors
app.use((req, res) => {
  res.status(404).json({ message: "Route not found" });
});

// Global error handler
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ message: "Something went wrong!" });
});

app.listen(PORT, function () {
  console.log(`Server is running on port ${PORT}`);
});