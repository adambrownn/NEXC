Orders CheckPoint =: ------- :Delivery Status
payment pending ===: 9 --- 0 :payement pending
order placed ======: 0 --- 1 :placed
accepted by restro : 1 |
accepted by d--boy : 2 |-- 2 :accepted
ready to delivered : 3 |
order picked up ===: 4 --- 3 :ontheway
order delivered ===: 5 --- 4 :delivered
cancelled by admin : 6 |
cancelled by restro: 7 |-- 5 :cancelled
cancelled by d-boy : 8 |
